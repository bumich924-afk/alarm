package com.example.alarmreminders

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class RingActivity : Activity() {
    companion object { const val CLOSE = "com.example.alarmreminders.CLOSE" }
    private val closer = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { finish() } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val id = intent.getIntExtra("id", -1)
        val ink = Color.parseColor("#12172B")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#FFD21F")); setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        root.addView(TextView(this).apply {
            text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            textSize = 80f; setTextColor(ink); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = intent.getStringExtra("title") ?: ""
            textSize = 30f; setTextColor(ink); gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(32))
        })
        fun btn(label: String, action: String, filled: Boolean) = Button(this).apply {
            text = label; textSize = 20f; isAllCaps = false
            setTextColor(if (filled) Color.parseColor("#FFD21F") else ink)
            setBackgroundColor(if (filled) ink else Color.TRANSPARENT)
            setOnClickListener {
                startService(Intent(this@RingActivity, RingService::class.java).setAction(action).putExtra("id", id))
                finish()
            }
        }
        root.addView(btn("Выключить", "STOP", true), LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(12) })
        root.addView(btn("Отложить на 5 минут", "SNOOZE", false), LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(root)
        ContextCompat.registerReceiver(this, closer, IntentFilter(CLOSE), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onDestroy() { unregisterReceiver(closer); super.onDestroy() }
}

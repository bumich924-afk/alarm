package com.example.alarmreminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

data class Reminder(val id: Int, val title: String, var time: Long, val daily: Boolean, var done: Boolean = false)

object Store {
    private const val PREFS = "reminders"
    fun all(c: Context): MutableList<Reminder> {
        val a = JSONArray(c.getSharedPreferences(PREFS, 0).getString("list", "[]"))
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Reminder(o.getInt("id"), o.getString("title"), o.getLong("time"), o.getBoolean("daily"), o.getBoolean("done"))
        }
    }
    fun save(c: Context, l: List<Reminder>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("time", it.time).put("daily", it.daily).put("done", it.done)) }
        c.getSharedPreferences(PREFS, 0).edit().putString("list", a.toString()).apply()
    }
    fun find(c: Context, id: Int) = all(c).firstOrNull { it.id == id }
    fun update(c: Context, r: Reminder) {
        val l = all(c); val i = l.indexOfFirst { it.id == r.id }
        if (i >= 0) { l[i] = r; save(c, l) }
    }
    fun remove(c: Context, id: Int) = save(c, all(c).filter { it.id != id })
}

object Scheduler {
    private fun pi(c: Context, id: Int, snooze: Boolean) = PendingIntent.getBroadcast(
        c, if (snooze) id or 0x40000000 else id,
        Intent(c, AlarmReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    fun set(c: Context, id: Int, at: Long, snooze: Boolean = false) {
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, id, snooze))
    }
    fun cancel(c: Context, id: Int) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(pi(c, id, false)); am.cancel(pi(c, id, true))
    }
    fun rescheduleAll(c: Context) = Store.all(c).filter { !it.done }.forEach { set(c, it.id, it.time) }
}

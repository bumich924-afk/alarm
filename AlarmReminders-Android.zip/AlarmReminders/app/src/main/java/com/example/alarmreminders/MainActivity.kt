package com.example.alarmreminders

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private var picked: Calendar = Calendar.getInstance().apply { add(Calendar.MINUTE, 2) }
    private lateinit var list: LinearLayout
    private lateinit var whenBtn: Button
    private val fmt = SimpleDateFormat("EEE, d MMM, HH:mm", Locale("ru"))
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        root.addView(TextView(this).apply { text = "Напоминалка-будильник"; textSize = 26f; setTextColor(Color.parseColor("#12172B")) })

        val title = EditText(this).apply { hint = "О чём напомнить"; setSingleLine() }
        whenBtn = Button(this).apply { isAllCaps = false; setOnClickListener { pickDateTime() } }
        val daily = CheckBox(this).apply { text = "Повторять каждый день" }
        val add = Button(this).apply {
            text = "Добавить напоминание"; isAllCaps = false
            setOnClickListener {
                val t = title.text.toString().trim()
                if (t.isEmpty()) { toast("Введите текст напоминания"); return@setOnClickListener }
                if (picked.timeInMillis <= System.currentTimeMillis()) { toast("Выберите время в будущем"); return@setOnClickListener }
                val r = Reminder((System.currentTimeMillis() % 1_000_000_000L).toInt(), t, picked.timeInMillis, daily.isChecked)
                Store.save(this@MainActivity, Store.all(this@MainActivity) + r)
                Scheduler.set(this@MainActivity, r.id, r.time)
                title.setText(""); render()
            }
        }
        listOf(title, whenBtn, daily, add).forEach { root.addView(it) }
        root.addView(TextView(this).apply { text = "Напоминания"; textSize = 20f; setPadding(0, dp(24), 0, dp(8)) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(ScrollView(this).apply { fitsSystemWindows = true; addView(root) })

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        updateWhen(); render()
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()) {
            toast("Разрешите полноэкранные уведомления, иначе сигнал не появится на заблокированном экране")
            runCatching { startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))) }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun updateWhen() { whenBtn.text = "Когда: " + fmt.format(picked.time) }

    private fun pickDateTime() {
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                picked = Calendar.getInstance().apply { set(y, m, d, h, min, 0); set(Calendar.MILLISECOND, 0) }
                updateWhen()
            }, picked.get(Calendar.HOUR_OF_DAY), picked.get(Calendar.MINUTE), true).show()
        }, picked.get(Calendar.YEAR), picked.get(Calendar.MONTH), picked.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun render() {
        list.removeAllViews()
        val items = Store.all(this).sortedWith(compareBy({ it.done }, { it.time }))
        if (items.isEmpty()) list.addView(TextView(this).apply { text = "Пока пусто. Добавьте первое напоминание выше." })
        items.forEach { r ->
            val row = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            row.addView(TextView(this).apply {
                text = r.title + "\n" + (if (r.done) "Сработало · " else "") + fmt.format(Date(r.time)) + (if (r.daily) " · каждый день" else "")
                alpha = if (r.done) 0.5f else 1f
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Удалить"; isAllCaps = false
                setOnClickListener { Scheduler.cancel(this@MainActivity, r.id); Store.remove(this@MainActivity, r.id); render() }
            })
            list.addView(row)
        }
    }
}

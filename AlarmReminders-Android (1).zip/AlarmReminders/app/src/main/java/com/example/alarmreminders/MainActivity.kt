package com.example.alarmreminders

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private var picked: Calendar = Calendar.getInstance().apply { add(Calendar.MINUTE, 2) }
    private var hasPick = false
    private lateinit var list: LinearLayout
    private lateinit var whenBtn: Button
    private lateinit var imgBtn: Button
    private val fmt = SimpleDateFormat("EEE, d MMM, HH:mm", Locale("ru"))
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        root.addView(TextView(this).apply { text = "Напоминалка-будильник"; textSize = 26f; setTextColor(Color.parseColor("#12172B")) })

        val title = EditText(this).apply { hint = "О чём напомнить"; setSingleLine() }
        whenBtn = Button(this).apply { isAllCaps = false; setOnClickListener { pickDateTime() } }
        imgBtn = Button(this).apply {
            isAllCaps = false; text = "Добавить картинку"
            setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7) }
        }
        val daily = CheckBox(this).apply { text = "Повторять каждый день" }
        val add = Button(this).apply {
            text = "Добавить напоминание"; isAllCaps = false
            setOnClickListener {
                val t = title.text.toString().trim()
                if (t.isEmpty()) { toast("Введите текст напоминания"); return@setOnClickListener }
                if (picked.timeInMillis <= System.currentTimeMillis()) { toast("Выберите время в будущем"); return@setOnClickListener }
                val id = (System.currentTimeMillis() % 1_000_000_000L).toInt()
                var path: String? = null
                if (hasPick) {
                    val f = File(filesDir, "img_$id.jpg")
                    if (File(filesDir, "tmp.jpg").renameTo(f)) path = f.absolutePath
                }
                val r = Reminder(id, t, picked.timeInMillis, daily.isChecked, false, path)
                Store.save(this@MainActivity, Store.all(this@MainActivity) + r)
                Scheduler.set(this@MainActivity, r.id, r.time)
                title.setText(""); hasPick = false; imgBtn.text = "Добавить картинку"; render()
            }
        }
        listOf(title, whenBtn, imgBtn, daily, add).forEach { root.addView(it) }
        root.addView(TextView(this).apply { text = "Напоминания"; textSize = 20f; setPadding(0, dp(24), 0, dp(8)) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(ScrollView(this).apply { fitsSystemWindows = true; addView(root) })

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        updateWhen(); render()
    }

    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        if (req == 7 && res == RESULT_OK) {
            val u = d?.data ?: return
            if (saveScaled(u, File(filesDir, "tmp.jpg"))) { hasPick = true; imgBtn.text = "Картинка выбрана (изменить)" }
            else toast("Не удалось открыть картинку")
        }
    }

    private fun saveScaled(u: Uri, dest: File): Boolean = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > 1600 || o.outHeight / s > 1600) s *= 2
        var bm = contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }!!
        val rot = runCatching {
            contentResolver.openInputStream(u)!!.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            }
        }.getOrDefault(0f)
        if (rot != 0f) bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(rot) }, true)
        dest.outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Exception) { false }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()) {
            toast("Разрешите полноэкранные уведомления, иначе сигнал не появится на заблокированном экране")
            runCatching { startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))) }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun updateWhen() { whenBtn.text = "Когда: " + fmt.format(picked.time) }

    private fun pickDateTime() {
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                picked = Calendar.getInstance().apply { set(y, m, d, h, min, 0); set(Calendar.MILLISECOND, 0) }
                updateWhen()
            }, picked.get(Calendar.HOUR_OF_DAY), picked.get(Calendar.MINUTE), true).show()
        }, picked.get(Calendar.YEAR), picked.get(Calendar.MONTH), picked.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun render() {
        list.removeAllViews()
        val items = Store.all(this).sortedWith(compareBy({ it.done }, { it.time }))
        if (items.isEmpty()) list.addView(TextView(this).apply { text = "Пока пусто. Добавьте первое напоминание выше." })
        items.forEach { r ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            r.image?.let { p ->
                val thumb = BitmapFactory.decodeFile(p, BitmapFactory.Options().apply { inSampleSize = 4 })
                if (thumb != null) row.addView(ImageView(this).apply { setImageBitmap(thumb); scaleType = ImageView.ScaleType.CENTER_CROP },
                    LinearLayout.LayoutParams(dp(56), dp(56)).apply { marginEnd = dp(12) })
            }
            row.addView(TextView(this).apply {
                text = r.title + "\n" + (if (r.done) "Сработало · " else "") + fmt.format(Date(r.time)) + (if (r.daily) " · каждый день" else "")
                alpha = if (r.done) 0.5f else 1f
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Удалить"; isAllCaps = false
                setOnClickListener {
                    Scheduler.cancel(this@MainActivity, r.id); Store.remove(this@MainActivity, r.id)
                    r.image?.let { File(it).delete() }; render()
                }
            })
            list.addView(row)
        }
    }
}

package com.example.alarmreminders

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat

class RingService : Service() {
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var currentId = -1

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val id = i?.getIntExtra("id", -1) ?: -1
        when (i?.action) {
            "STOP" -> { finish(id, false); return START_NOT_STICKY }
            "SNOOZE" -> { finish(id, true); return START_NOT_STICKY }
        }
        val r = Store.find(this, id)
        if (r == null) { stopSelf(); return START_NOT_STICKY }
        currentId = id
        startForegroundCompat(r)
        startSound()
        handler.postDelayed({ finish(id, true) }, 2 * 60_000L) // авто-откладывание через 2 минуты
        return START_NOT_STICKY
    }

    private fun startForegroundCompat(r: Reminder) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ring", "Сигналы напоминаний", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null); enableVibration(false)
            }
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val full = PendingIntent.getActivity(
            this, r.id,
            Intent(this, RingActivity::class.java).putExtra("id", r.id).putExtra("title", r.title)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags
        )
        fun act(a: String, code: Int) = PendingIntent.getService(
            this, code + r.id, Intent(this, RingService::class.java).setAction(a).putExtra("id", r.id), flags
        )
        val n = NotificationCompat.Builder(this, "ring")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(r.title).setContentText("Напоминание")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true).setFullScreenIntent(full, true).setContentIntent(full)
            .addAction(0, "Выключить", act("STOP", 1))
            .addAction(0, "Отложить на 5 мин", act("SNOOZE", 2))
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
    }

    private fun startSound() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(this@RingService, uri)
                isLooping = true; prepare(); start()
            }
        } catch (e: Exception) { /* звука не будет, но вибрация и экран сработают */ }
        val v = getSystemService(Vibrator::class.java)
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
    }

    private fun finish(id: Int, snooze: Boolean) {
        handler.removeCallbacksAndMessages(null)
        player?.runCatching { stop(); release() }; player = null
        getSystemService(Vibrator::class.java).cancel()
        val r = Store.find(this, id)
        if (r != null) {
            fun advance() { while (r.time <= System.currentTimeMillis()) r.time += 86_400_000L }
            if (snooze) {
                val at = System.currentTimeMillis() + 5 * 60_000L
                if (r.daily) {
                    advance(); Store.update(this, r)
                    Scheduler.set(this, r.id, r.time); Scheduler.set(this, r.id, at, snooze = true)
                } else { r.time = at; Store.update(this, r); Scheduler.set(this, r.id, at) }
            } else if (r.daily) {
                advance(); Store.update(this, r); Scheduler.set(this, r.id, r.time)
            } else { r.done = true; Store.update(this, r) }
        }
        sendBroadcast(Intent(RingActivity.CLOSE).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); player?.release(); super.onDestroy() }
}

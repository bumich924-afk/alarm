Напоминалка: Android-проект (Kotlin). Собирается через GitHub Actions или Android Studio.

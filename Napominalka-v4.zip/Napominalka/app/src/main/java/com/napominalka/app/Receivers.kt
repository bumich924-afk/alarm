package com.napominalka.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val r = Store.find(c, id) ?: return
        try {
            ContextCompat.startForegroundService(c, Intent(c, RingService::class.java).putExtra("id", id))
        } catch (e: Exception) {
            fallback(c, r)
        }
    }

    /** Запасной путь: обычное громкое уведомление, если система не дала запустить сервис. */
    private fun fallback(c: Context, r: Reminder) {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel("ring_fb", "Сигналы (запасной канал)", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            )
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
            val pi = PendingIntent.getActivity(
                c, r.id,
                Intent(c, RingActivity::class.java).putExtra("id", r.id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(c, "ring_fb")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(r.title).setContentText("Напоминание")
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setFullScreenIntent(pi, true).setContentIntent(pi).setAutoCancel(true)
                .build()
            nm.notify(r.id, n)
        } catch (e: Exception) { }
        if (r.daily) {
            r.time = Store.nextDaily(r.time)
            Store.update(c, r)
            Scheduler.set(c, r.id, r.time)
        } else {
            r.done = true
            Store.update(c, r)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Scheduler.rescheduleAll(c)
    }
}

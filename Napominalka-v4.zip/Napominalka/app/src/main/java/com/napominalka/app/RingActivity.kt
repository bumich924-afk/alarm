package com.napominalka.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RingActivity : Activity() {
    companion object { var current: RingActivity? = null }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val id = intent.getIntExtra("id", -1)
        val r = Store.find(this, id)
        val title = r?.title ?: "Напоминание"
        var bmp: Bitmap? = null
        try { if (r?.image != null) bmp = BitmapFactory.decodeFile(r.image) } catch (e: Throwable) { }

        val ink = Color.parseColor("#12172B")
        val yellow = Color.parseColor("#FFD21F")
        val textColor = if (bmp != null) Color.WHITE else ink

        val frame = FrameLayout(this)
        if (bmp != null) {
            frame.setBackgroundColor(Color.BLACK)
            val iv = ImageView(this)
            iv.setImageBitmap(bmp)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            frame.addView(iv, FrameLayout.LayoutParams(-1, -1))
            val shade = View(this)
            shade.setBackgroundColor(Color.parseColor("#99000000"))
            frame.addView(shade, FrameLayout.LayoutParams(-1, -1))
        } else {
            frame.setBackgroundColor(yellow)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(dp(24), dp(24), dp(24), dp(24))

        val clock = TextView(this)
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        clock.textSize = 84f
        clock.typeface = Typeface.DEFAULT_BOLD
        clock.setTextColor(textColor)
        clock.gravity = Gravity.CENTER
        root.addView(clock)

        val label = TextView(this)
        label.text = title
        label.textSize = 30f
        label.setTextColor(textColor)
        label.gravity = Gravity.CENTER
        label.setPadding(0, dp(12), 0, dp(36))
        root.addView(label)

        root.addView(makeButton("Выключить", RingService.ACTION_STOP, id, true, bmp != null, ink, yellow),
            LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(12) })
        root.addView(makeButton("Отложить на 5 минут", RingService.ACTION_SNOOZE, id, false, bmp != null, ink, yellow),
            LinearLayout.LayoutParams(-1, dp(64)))

        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    private fun makeButton(text: String, action: String, id: Int, filled: Boolean, onPhoto: Boolean, ink: Int, yellow: Int): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 20f
        b.isAllCaps = false
        b.stateListAnimator = null
        val bg = GradientDrawable()
        bg.cornerRadius = dp(32).toFloat()
        if (filled) {
            bg.setColor(if (onPhoto) yellow else ink)
            b.setTextColor(if (onPhoto) ink else yellow)
        } else {
            bg.setColor(if (onPhoto) Color.parseColor("#33FFFFFF") else Color.TRANSPARENT)
            bg.setStroke(dp(2), if (onPhoto) Color.WHITE else ink)
            b.setTextColor(if (onPhoto) Color.WHITE else ink)
        }
        b.background = bg
        b.setOnClickListener {
            startService(Intent(this, RingService::class.java).setAction(action).putExtra("id", id))
            finish()
        }
        return b
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }
}

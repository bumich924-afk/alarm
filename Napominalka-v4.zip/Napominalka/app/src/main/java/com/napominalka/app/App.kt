package com.napominalka.app

import android.app.Application
import android.util.Log
import java.io.File

/** Если приложение вылетит, текст ошибки сохранится и будет показан при следующем запуске. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText(Log.getStackTraceString(e)) } catch (x: Exception) { }
            old?.uncaughtException(t, e)
        }
    }
}

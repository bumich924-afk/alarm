package com.napominalka.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val ink = Color.parseColor("#12172B")
    private val yellow = Color.parseColor("#FFD21F")
    private val page = Color.parseColor("#F3F4F9")
    private val muted = Color.parseColor("#5D6580")
    private val line = Color.parseColor("#D9DCE8")
    private val red = Color.parseColor("#C92A52")

    private var picked: Calendar = Calendar.getInstance()
    private var hasPick = false
    private lateinit var list: LinearLayout
    private lateinit var whenBtn: Button
    private lateinit var imgBtn: Button
    private lateinit var crashBox: LinearLayout
    private lateinit var crashText: TextView
    private val fmt = SimpleDateFormat("EEE, d MMMM, HH:mm", Locale("ru"))

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(top)
        return p
    }

    private fun button(label: String, filled: Boolean, size: Float = 16f): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = size
        b.stateListAnimator = null
        b.setTextColor(ink)
        b.background = if (filled) shape(yellow, 14) else shape(Color.TRANSPARENT, 14, line)
        return b
    }

    private fun inMinutes(m: Int): Calendar {
        val c = Calendar.getInstance()
        c.add(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        picked = inMinutes(5)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(20), dp(16), dp(32))

        val h1 = TextView(this)
        h1.text = "Напоминалка"
        h1.textSize = 30f
        h1.typeface = Typeface.DEFAULT_BOLD
        h1.setTextColor(ink)
        content.addView(h1)
        val sub = TextView(this)
        sub.text = "Сигнал на весь экран со звуком, как у будильника"
        sub.textSize = 14f
        sub.setTextColor(muted)
        content.addView(sub, lp(2))

        // отчёт об ошибке, если приложение раньше вылетало
        crashBox = LinearLayout(this)
        crashBox.orientation = LinearLayout.VERTICAL
        crashBox.setPadding(dp(12), dp(12), dp(12), dp(12))
        crashBox.background = shape(Color.parseColor("#FFE3E8"), 12)
        crashBox.visibility = View.GONE
        val crashHead = TextView(this)
        crashHead.text = "Прошлый раз приложение закрылось с ошибкой. Скопируйте текст ниже (долгое нажатие) и отправьте его разработчику."
        crashHead.setTextColor(ink)
        crashBox.addView(crashHead)
        crashText = TextView(this)
        crashText.textSize = 11f
        crashText.setTextColor(ink)
        crashText.setTextIsSelectable(true)
        crashBox.addView(crashText, lp(8))
        val crashClose = button("Скрыть", false, 14f)
        crashClose.setOnClickListener { File(filesDir, "crash.txt").delete(); crashBox.visibility = View.GONE }
        crashBox.addView(crashClose, lp(8))
        content.addView(crashBox, lp(16))

        // карточка нового напоминания
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(16), dp(16), dp(16))
        card.background = shape(Color.WHITE, 18, line)

        val title = EditText(this)
        title.hint = "О чём напомнить"
        title.setSingleLine()
        title.setTextColor(ink)
        card.addView(title, lp())

        whenBtn = button("", false)
        whenBtn.setOnClickListener { pickDateTime() }
        card.addView(whenBtn, lp(10))

        val quick = LinearLayout(this)
        val quickItems = listOf("через 1 мин" to 1, "через 10 мин" to 10, "через 1 час" to 60)
        for ((label, m) in quickItems) {
            val q = button(label, false, 13f)
            q.setOnClickListener { picked = inMinutes(m); updateWhen() }
            val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            p.marginEnd = dp(6)
            quick.addView(q, p)
        }
        card.addView(quick, lp(6))

        imgBtn = button("Добавить картинку", false)
        imgBtn.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7) }
        card.addView(imgBtn, lp(6))

        val daily = CheckBox(this)
        daily.text = "Повторять каждый день"
        daily.setTextColor(ink)
        card.addView(daily, lp(6))

        val add = button("Добавить напоминание", true, 17f)
        add.setOnClickListener {
            val t = title.text.toString().trim()
            if (t.isEmpty()) { toast("Введите, о чём напомнить"); return@setOnClickListener }
            if (picked.timeInMillis <= System.currentTimeMillis()) {
                toast("Это время уже прошло. Выберите новое.")
                pickDateTime()
                return@setOnClickListener
            }
            val id = (System.currentTimeMillis() % 1_000_000_000L).toInt()
            var path: String? = null
            if (hasPick) {
                val f = File(filesDir, "img_$id.jpg")
                if (File(filesDir, "tmp.jpg").renameTo(f)) path = f.absolutePath
            }
            val r = Reminder(id, t, picked.timeInMillis, daily.isChecked, false, path)
            Store.add(this, r)
            Scheduler.set(this, r.id, r.time)
            toast("Добавлено: " + fmt.format(Date(r.time)))
            title.setText("")
            hasPick = false
            imgBtn.text = "Добавить картинку"
            picked = inMinutes(5)
            updateWhen()
            render()
        }
        card.addView(add, lp(10))
        content.addView(card, lp(16))

        val h2 = TextView(this)
        h2.text = "Мои напоминания"
        h2.textSize = 20f
        h2.typeface = Typeface.DEFAULT_BOLD
        h2.setTextColor(ink)
        content.addView(h2, lp(24))

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        content.addView(list, lp(8))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(page)
        scroll.fitsSystemWindows = true
        scroll.addView(content)
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        showCrash()
        updateWhen()
        render()
    }

    private fun showCrash() {
        val f = File(filesDir, "crash.txt")
        if (f.exists()) {
            try {
                crashText.text = f.readText().take(3500)
                crashBox.visibility = View.VISIBLE
            } catch (e: Exception) { }
        }
    }

    override fun onResume() {
        super.onResume()
        // про полноэкранные уведомления спрашиваем один раз
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 34 && !prefs.getBoolean("fsi_asked", false)) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.canUseFullScreenIntent()) {
                prefs.edit().putBoolean("fsi_asked", true).apply()
                toast("Разрешите полноэкранные уведомления, иначе сигнал не появится на заблокированном экране")
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
                } catch (e: Exception) { }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val u = data?.data ?: return
            if (saveScaled(u, File(filesDir, "tmp.jpg"))) {
                hasPick = true
                imgBtn.text = "Картинка выбрана (изменить)"
            } else {
                toast("Не удалось открыть картинку")
            }
        }
    }

    private fun saveScaled(u: Uri, dest: File): Boolean {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 1600 || o.outHeight / s > 1600) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            var bm: Bitmap = contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o2) }!!
            var rot = 0f
            try {
                contentResolver.openInputStream(u)!!.use {
                    val ori = ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
                    rot = when (ori) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
                }
            } catch (e: Exception) { }
            if (rot != 0f) {
                val m = Matrix()
                m.postRotate(rot)
                bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, m, true)
            }
            dest.outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            return true
        } catch (e: Throwable) {
            return false
        }
    }

    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun updateWhen() { whenBtn.text = "Когда: " + fmt.format(picked.time) + "\n(нажмите, чтобы изменить)" }

    private fun pickDateTime() {
        val theme = android.R.style.Theme_Holo_Light_Dialog
        DatePickerDialog(this, theme, { _, y, m, d ->
            TimePickerDialog(this, theme, { _, h, min ->
                val c = Calendar.getInstance()
                c.set(y, m, d, h, min, 0)
                c.set(Calendar.MILLISECOND, 0)
                picked = c
                updateWhen()
            }, picked.get(Calendar.HOUR_OF_DAY), picked.get(Calendar.MINUTE), true).show()
        }, picked.get(Calendar.YEAR), picked.get(Calendar.MONTH), picked.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun render() {
        list.removeAllViews()
        val items = Store.all(this).sortedWith(compareBy<Reminder>({ it.done }, { it.time }))
        if (items.isEmpty()) {
            val e = TextView(this)
            e.text = "Пока пусто. Добавьте первое напоминание выше."
            e.setTextColor(muted)
            list.addView(e)
            return
        }
        for (r in items) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(8), dp(10))
            row.background = shape(Color.WHITE, 14, line)
            row.alpha = if (r.done) 0.55f else 1f

            if (r.image != null) {
                val opts = BitmapFactory.Options()
                opts.inSampleSize = 4
                val thumb = BitmapFactory.decodeFile(r.image, opts)
                if (thumb != null) {
                    val iv = ImageView(this)
                    iv.setImageBitmap(thumb)
                    iv.scaleType = ImageView.ScaleType.CENTER_CROP
                    val p = LinearLayout.LayoutParams(dp(56), dp(56))
                    p.marginEnd = dp(12)
                    row.addView(iv, p)
                }
            }

            val texts = LinearLayout(this)
            texts.orientation = LinearLayout.VERTICAL
            val t1 = TextView(this)
            t1.text = r.title
            t1.textSize = 17f
            t1.typeface = Typeface.DEFAULT_BOLD
            t1.setTextColor(ink)
            texts.addView(t1)
            val t2 = TextView(this)
            t2.text = (if (r.done) "Сработало: " else "") + fmt.format(Date(r.time)) + (if (r.daily) ", каждый день" else "")
            t2.textSize = 13f
            t2.setTextColor(muted)
            texts.addView(t2)
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val del = Button(this)
            del.text = "Удалить"
            del.isAllCaps = false
            del.textSize = 14f
            del.setTextColor(red)
            del.setBackgroundColor(Color.TRANSPARENT)
            del.stateListAnimator = null
            del.setOnClickListener {
                Scheduler.cancel(this, r.id)
                Store.remove(this, r.id)
                if (r.image != null) File(r.image).delete()
                render()
            }
            row.addView(del)
            list.addView(row, lp(8))
        }
    }
}

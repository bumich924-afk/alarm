package com.napominalka.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Reminder(
    val id: Int,
    val title: String,
    var time: Long,
    val daily: Boolean,
    var done: Boolean = false,
    val image: String? = null
)

object Store {
    private const val PREFS = "reminders"
    private const val KEY = "list"

    fun all(c: Context): MutableList<Reminder> {
        val out = mutableListOf<Reminder>()
        try {
            val a = JSONArray(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val img = o.optString("image", "")
                out.add(
                    Reminder(
                        o.getInt("id"), o.getString("title"), o.getLong("time"),
                        o.optBoolean("daily", false), o.optBoolean("done", false),
                        if (img.isEmpty()) null else img
                    )
                )
            }
        } catch (e: Exception) { }
        return out
    }

    fun save(c: Context, list: List<Reminder>) {
        val a = JSONArray()
        for (r in list) {
            a.put(
                JSONObject().put("id", r.id).put("title", r.title).put("time", r.time)
                    .put("daily", r.daily).put("done", r.done).put("image", r.image ?: "")
            )
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    fun find(c: Context, id: Int): Reminder? = all(c).firstOrNull { it.id == id }

    fun add(c: Context, r: Reminder) { val l = all(c); l.add(r); save(c, l) }

    fun update(c: Context, r: Reminder) {
        val l = all(c)
        val i = l.indexOfFirst { it.id == r.id }
        if (i >= 0) { l[i] = r; save(c, l) }
    }

    fun remove(c: Context, id: Int) { save(c, all(c).filter { it.id != id }) }

    /** Ближайшее будущее время для ежедневного напоминания (с сохранением часов и минут). */
    fun nextDaily(t: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = t
        val now = System.currentTimeMillis()
        while (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }
}

object Scheduler {
    private fun pending(c: Context, id: Int, snooze: Boolean): PendingIntent {
        val code = if (snooze) (id or 0x40000000) else id
        return PendingIntent.getBroadcast(
            c, code, Intent(c, AlarmReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun set(c: Context, id: Int, at: Long, snooze: Boolean = false) {
        try {
            val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pending(c, id, snooze))
        } catch (e: Exception) { }
    }

    fun cancel(c: Context, id: Int) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pending(c, id, false))
            am.cancel(pending(c, id, true))
        } catch (e: Exception) { }
    }

    fun rescheduleAll(c: Context) {
        for (r in Store.all(c)) if (!r.done) set(c, r.id, r.time)
    }
}

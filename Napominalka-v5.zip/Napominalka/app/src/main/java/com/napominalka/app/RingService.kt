package com.napominalka.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat

class RingService : Service() {
    companion object {
        const val ACTION_STOP = "STOP"
        const val ACTION_SNOOZE = "SNOOZE"
        const val NOTIF_ID = 1
    }

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra("id", -1) ?: -1
        val action = intent?.action
        if (action == ACTION_STOP) { finishRing(id, false); return START_NOT_STICKY }
        if (action == ACTION_SNOOZE) { finishRing(id, true); return START_NOT_STICKY }

        val r = Store.find(this, id)
        try {
            startForegroundCompat(id, r?.title ?: "Напоминание")
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (r == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startSound()
        try {
            startActivity(Intent(this, RingActivity::class.java).putExtra("id", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
        // если никто не нажал кнопку, через 2 минуты сигнал сам откладывается на 5 минут
        handler.postDelayed({ finishRing(id, true) }, 2 * 60_000L)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat(id: Int, title: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel("ring", "Сигналы напоминаний", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val full = PendingIntent.getActivity(
            this, id,
            Intent(this, RingActivity::class.java).putExtra("id", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            flags
        )
        val stop = PendingIntent.getService(
            this, id, Intent(this, RingService::class.java).setAction(ACTION_STOP).putExtra("id", id), flags
        )
        val snooze = PendingIntent.getService(
            this, id, Intent(this, RingService::class.java).setAction(ACTION_SNOOZE).putExtra("id", id), flags
        )
        val n = NotificationCompat.Builder(this, "ring")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText("Напоминание")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setFullScreenIntent(full, true).setContentIntent(full)
            .addAction(0, "Выключить", stop)
            .addAction(0, "Отложить на 5 мин", snooze)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun startSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) { }
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
        } catch (e: Exception) { }
    }

    private fun finishRing(id: Int, snooze: Boolean) {
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (e: Exception) { }
        try { player?.release() } catch (e: Exception) { }
        player = null
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (e: Exception) { }
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id) } catch (e: Exception) { }

        val r = Store.find(this, id)
        if (r != null) {
            if (snooze) {
                val at = System.currentTimeMillis() + 5 * 60_000L
                if (r.daily) {
                    r.time = Store.nextDaily(r.time)
                    Store.update(this, r)
                    Scheduler.set(this, r.id, r.time)
                    Scheduler.set(this, r.id, at, true)
                } else {
                    r.time = at
                    r.done = false
                    Store.update(this, r)
                    Scheduler.set(this, r.id, at)
                }
            } else if (r.daily) {
                r.time = Store.nextDaily(r.time)
                Store.update(this, r)
                Scheduler.set(this, r.id, r.time)
            } else {
                r.done = true
                Store.update(this, r)
            }
        }
        RingActivity.current?.finish()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { player?.release() } catch (e: Exception) { }
        super.onDestroy()
    }
}

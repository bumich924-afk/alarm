plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.napominalka.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.napominalka.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.1"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1") }
